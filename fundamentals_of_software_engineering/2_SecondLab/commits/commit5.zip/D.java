public class D extends J {

    private String d = "test";

    private String j = "test";

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
