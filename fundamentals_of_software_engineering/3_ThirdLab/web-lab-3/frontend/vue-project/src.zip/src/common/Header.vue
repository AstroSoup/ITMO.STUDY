<script>

import { mapState } from 'pinia'
import { useAuthStore } from '@/stores/AuthStore.js'
import { useHistoryStore } from '@/stores/HistoryStore.js';

export default {
name: 'HeaderBar',
computed: {
    ...mapState(useAuthStore, ['auth_header']),
    isAuth() {
        if (this.auth_header === '') {
            return false
        }
        return true
    }
},
methods: {
    logout() {
        
        const authStore = useAuthStore()
        authStore.logout()
        authStore.auth_header = ''

        const historyStore = useHistoryStore()
        historyStore.clear()
        historyStore.clear_input()

        this.$router.push({ name: 'start' })
        }
    }
}
</script>

<template>
    <header class="header">
        <div class="header-inner">

            <div class="name">
                <h2>Горин Семён Дмитриевич P3208</h2>
            </div>
            <div class="discipline">
                <h2>Веб-программирование</h2>
            </div>
            <div class="work">
                <h2>Лабораторная работа № 3</h2>
            </div>
            <div class="auth-actions">
                <button v-if="isAuth" @click="logout">Выйти</button>
            </div>
        </div>
    </header>
</template>

<style scoped>
    .header{
        background: linear-gradient(90deg, red, orange, yellow, green, blue, indigo, violet);
    }
    .header-inner{
        padding: 15px;
        color: white;
        font-size: 18px;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .identity{
        font-weight:600;
    }
    button{
        background:transparent;
        border:1px solid rgba(255,255,255,0.6);
        padding:8px 12px;
        color:white;
        border-radius:8px;
    }
    button:hover {
        cursor:pointer;
    }
</style>