<script>
export default { name: 'FooterBar' }
</script>

<template>
<footer class="footer">
<div class="footer-inner">
        <div id="contacts">
        <div id="links">
            <a href="https://t.me/astro_soup">
                <img src="https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white">
            </a>
            <a href="https://vk.com/astro_soup">
                <img src="https://img.shields.io/badge/вконтакте-%232E87FB.svg?&style=for-the-badge&logo=vk&logoColor=white">
            </a>
            <a href="https://discord.com/users/697719405748158465">
                <img src="https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white">
            </a>
            <a href="mailto:astro_soup@niuitmo.ru">
                <img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white">
            </a>
        </div>
        <img src="@/assets/tsukasa-phone.gif" id="tsukasa">
    </div>
</div>
</footer>
</template>

<style scoped>
.footer{
    background: linear-gradient(90deg, violet, indigo, blue, green, yellow, orange, red);
    padding:14px;
    color:white
}
.footer-inner{
    max-width:var(--max-width);
    margin:0 auto;
    text-align:center

}

img {
    height: 35px;
    transition: transform 0.2s;
}

img:hover {
    transform: scale(1.05);
}


</style>