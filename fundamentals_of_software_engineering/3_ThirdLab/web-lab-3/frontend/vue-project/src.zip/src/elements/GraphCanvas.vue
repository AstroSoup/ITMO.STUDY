<script>

import { useHistoryStore } from '@/stores/HistoryStore.js'
import PopupWindow from '@/common/PopupWindow.vue';


export default {
  name: 'GraphCanvas',
  components: { PopupWindow },
  props: {
    x: Number,
    y: Number,
    r: Number,
    hit: {type: Number, default: -1},
    size: { type: Number, default: 400 },
    scale: { type: Number, default: 40 }
  },
  emits: ['update:x', 'update:y'],
  data() {
    return {
      errorMsg: '',
      errorTitle: ''
    }
  },
  watch: {
    x() { this.drawGraph(); },
    y() { this.drawGraph(); },
    r() { this.drawGraph(); }
  },
  computed: {
    history() {
      const history = useHistoryStore.history
      return history
    }
  },

  mounted() {
    this.drawGraph();
  },
  methods: {
    drawGraph() {
      const canvas = this.$refs.graph;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;
      const s = this.scale;

      ctx.clearRect(0, 0, width, height);

      // Axes
      ctx.beginPath();
      ctx.moveTo(0, centerY);
      ctx.lineTo(width, centerY);
      ctx.moveTo(centerX, 0);
      ctx.lineTo(centerX, height);
      ctx.strokeStyle = '#2c3e50';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = '#2c3e50';
      ctx.font = '12px Arial';
      for (let i = -5; i <= 5; i++) {
        if (i === 0) continue;
        const xPos = centerX + i * s;
        const yPos = centerY - i * s;

        // X ticks
        ctx.beginPath();
        ctx.moveTo(xPos, centerY - 5);
        ctx.lineTo(xPos, centerY + 5);
        ctx.stroke();
        ctx.fillText(i.toString(), xPos - 4, centerY + 15);

        // Y ticks
        ctx.beginPath();
        ctx.moveTo(centerX - 5, yPos);
        ctx.lineTo(centerX + 5, yPos);
        ctx.stroke();
        ctx.fillText(i.toString(), centerX + 8, yPos + 4);
      }
      if (this.r === '') {
        return
      }

      if (this.r <= 0) {
        this.errorTitle = 'График области не отрисован'
        this.errorMsg = 'Выбранный радиус не может быть отрисован. Пожалуйста, выберите положительный радиус.'
        return
      }
      // Draw area
      if (this.r) {
        const Rpx = this.r * s;
        ctx.fillStyle = 'rgba(52,152,219,0.4)';

        // Quarter circle
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY, Rpx, 1.5 * Math.PI, 2 * Math.PI);
        ctx.closePath();
        ctx.fill();

        // Rectangle
        ctx.fillRect(centerX - Rpx / 2, centerY - Rpx, Rpx / 2, Rpx);

        // Triangle
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(centerX - Rpx / 2, centerY);
        ctx.lineTo(centerX, centerY + Rpx);
        ctx.closePath();
        ctx.fill();
      }

      // Draw selected point if exists
      if (this.x !== null && this.y !== null && !isNaN(this.x) && !isNaN(this.y)) {
        const px = centerX + this.x * s;
        const py = centerY - this.y * s;
        ctx.beginPath();
        ctx.arc(px, py, 3, 0, Math.PI * 2);
        ctx.fillStyle = 'black';
        ctx.fill();
      }
      const historyStore = useHistoryStore()
      historyStore.history.forEach(pt => {
        if (this.r === pt.r) {
          const px = centerX + pt.x * s
          const py = centerY - pt.y * s
          ctx.beginPath()
          ctx.arc(px, py, 3, 0, Math.PI * 2)
          ctx.fillStyle = pt.hit ? 'hsl(140, 80%, 40%)' : 'red'
          ctx.fill()
        }
      })
    },

    handleCanvasClick(event) {
      if (!this.r) {
        this.errorTitle = 'График области не отрисован'
        this.errorMsg = 'Сначала выберите радиус R';
        return;
      }

      const canvas = this.$refs.graph;
      const rect = canvas.getBoundingClientRect();
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const s = this.scale;

      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;

      const realX = (Math.round((x - centerX) / s) < 3 ? Math.round((x - centerX) / s) : 3);
      const realY = -((y - centerY) / s).toFixed(2) > -3 ? -((y - centerY) / s).toFixed(2) : -3;

      this.$emit('update:x', realX);
      this.$emit('update:y', Number(realY));
    }
  }
};
</script>

<template>
  <PopupWindow v-if="errorMsg" :message="errorMsg" :title="errorTitle" @acknowledged="errorMsg=''" />
  <canvas
    ref="graph"
    :width="size"
    :height="size"
    class="graph-canvas"
    @click="handleCanvasClick"
  ></canvas>
</template>

<style scoped>
.graph-canvas {
  margin: 20px auto;
  display: block;
  border: 2px solid black;
  border-radius: 8px;
  background: #ffffff;
}
.graph-canvas:hover {
  cursor: crosshair;
}
</style>
